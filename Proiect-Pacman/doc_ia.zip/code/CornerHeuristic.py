def cornersHeuristic(state: Any, problem: CornersProblem):
    corners = problem.corners
    walls = problem.walls
    current_position = state[0]
    unvisited_corners = state[1]
    if len(unvisited_corners) == 0:
        return 0
    farthest_distance = 0
    for corner in unvisited_corners:
        distance = util.manhattanDistance(current_position, corner)
        if distance > farthest_distance:
            farthest_distance = distance
    return farthest_distance