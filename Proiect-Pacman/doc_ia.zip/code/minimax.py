class MinimaxAgent(MultiAgentSearchAgent):
    def getAction(self, gameState):
    
        def minimax(state, depth, agentIndex):
            if depth == 0 or state.isWin() or state.isLose():
                return self.evaluationFunction(state), None
            if agentIndex == 0:  #Pacman
                bestValue = float("-inf")
            else:  #Ghost
                bestValue = float("inf")
            bestAction = None
            legalActions = state.getLegalActions(agentIndex)
            for action in legalActions:
                successor = state.generateSuccessor(agentIndex, action)
                value, _ = minimax(successor, depth - 1, (agentIndex + 1) %
                    state.getNumAgents())
                if (agentIndex == 0 and value > bestValue) or (agentIndex != 0 
                    and value < bestValue):
                        bestValue = value
                        bestAction = action
            return bestValue, bestAction
            
        _, bestAction = minimax(gameState, self.depth * gameState.getNumAgents(), 0)
        return bestAction