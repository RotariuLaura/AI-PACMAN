def expectimax(state, depth, agentIndex):
    if depth == 0 or state.isWin() or state.isLose():
        return self.evaluationFunction(state), None
    if agentIndex == 0:  # Pacman's turn
        bestValue = float("-inf")
        bestAction = None
        for action in state.getLegalActions(agentIndex):
            successor = state.generateSuccessor(agentIndex, action)
            value, _ = expectimax(successor, depth - 1, (agentIndex + 1) % 
            state.getNumAgents())
            if value > bestValue:
                bestValue = value
                bestAction = action
        return bestValue, bestAction
    else:  # Ghosts' turn
        sumValues = 0.0
        legalActions = state.getLegalActions(agentIndex)
        probability = 1.0 / len(legalActions)
        for action in legalActions:
            successor = state.generateSuccessor(agentIndex, action)
            value, _ = expectimax(successor, depth - 1, (agentIndex + 1) % 
            state.getNumAgents())
            sumValues += value * probability
        return sumValues, None
