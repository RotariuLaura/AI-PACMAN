 def evaluationFunction(self, currentGameState: GameState, action):
        # information from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]
        evaluation = successorGameState.getScore()  
        capsules = successorGameState.getCapsules()
        closestFoodDistance = float('inf')
        closestGhostDistance = float('inf')
        for food in newFood.asList():
            distance = util.manhattanDistance(newPos, food)
            if distance < closestFoodDistance:
                closestFoodDistance = distance
        for ghostState in newGhostStates:
            ghostPos = ghostState.getPosition()
            distance = util.manhattanDistance(newPos, ghostPos)
            if distance < closestGhostDistance:
                closestGhostDistance = distance
        evaluation = successorGameState.getScore()  
        if closestGhostDistance <= 1:
            evaluation -= 500 
        else:
            evaluation += 1.0 / (closestFoodDistance + 1)  
        if newPos in capsules:
            evaluation += 500 
        return evaluation