  def getSuccessors(self, state: Any):
        successors = []
        for action in [Directions.NORTH, Directions.SOUTH, Directions.EAST,
        Directions.WEST]:
            x, y = state[0]
            dx, dy = Actions.directionToVector(action)
            nextx, nexty = int(x + dx), int(y + dy)
            if not self.walls[nextx][nexty]:
                next_state = (nextx, nexty)
                cost = 1
                set_of_corners = set(state[1])
                if next_state in self.corners and next_state in set_of_corners:
                    set_of_corners.remove(next_state)
                successors.append(((next_state, tuple(set_of_corners)), action, cost))
        self._expanded += 1
        return successors