def foodHeuristic(state: Tuple[Tuple, List[List]], problem: FoodSearchProblem):
    uneaten = foodGrid.asList()
    if len(uneaten) == 0:
        return 0
    farthest_distance = 0
    for food in uneaten:
        distance = util.manhattanDistance(position, food)
        if distance > farthest_distance:
            farthest_distance = distance
    return farthest_distance