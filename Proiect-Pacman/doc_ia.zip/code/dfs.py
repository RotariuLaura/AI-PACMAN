def depthFirstSearch(problem: SearchProblem):
    state_stack = util.Stack()
    start = problem.getStartState()
    state_stack.push((start, []))  
    visited = set() 

    while not state_stack.isEmpty():
        popped_element = state_stack.pop()
        current_state = popped_element[0]
        path = popped_element[1]
        if problem.isGoalState(current_state):
            return path  
        if current_state not in visited:
            visited.add(current_state)
            successors = problem.getSuccessors(current_state)
            for next_state, direction, _ in successors:
                if next_state not in visited:
                    state_stack.push((next_state, path + [direction]))