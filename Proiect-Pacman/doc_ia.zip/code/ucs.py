def uniformCostSearch(problem: SearchProblem):
    state_queue = util.PriorityQueue()
    start = problem.getStartState()
    state_queue.push((start, [], 0), 0)  
    visited = set() 

    while not state_queue.isEmpty():
        popped_element = state_queue.pop()
        current_state = popped_element[0]
        path = popped_element[1]
        cost = popped_element[2]
        if problem.isGoalState(current_state):
            return path  
        if current_state not in visited:
            visited.add(current_state)
            successors = problem.getSuccessors(current_state)
            for next_state, direction, state_cost in successors:
                if next_state not in visited:
                    total_cost = cost + state_cost
                    state_queue.push((next_state, path + [direction], total_cost),
                    total_cost)
