def betterEvaluationFunction(currentGameState: GameState):
    pacmanPosition = currentGameState.getPacmanPosition()
    foodGrid = currentGameState.getFood()
    ghostStates = currentGameState.getGhostStates()
    capsules = currentGameState.getCapsules()
    evaluation = currentGameState.getScore()
    closestFoodDistance = float('inf')
    for food in foodGrid.asList():
        distance = util.manhattanDistance(pacmanPosition, food)
        if distance < closestFoodDistance:
            closestFoodDistance = distance
    for ghostState in ghostStates:
        ghostPos = ghostState.getPosition()
        distance = util.manhattanDistance(pacmanPosition, ghostPos)
        if distance <= 1:
            evaluation -= 500
        else :
            evaluation += 1.0 / (closestFoodDistance + 1)
    if pacmanPosition in capsules:
        evaluation += 500 
    return evaluation