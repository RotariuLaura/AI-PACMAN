class AlphaBetaAgent(MultiAgentSearchAgent):
    def getAction(self, gameState):
        def alphaBeta(state, depth, alpha, beta, agentIndex):
            if depth == 0 or state.isWin() or state.isLose():
                return self.evaluationFunction(state), None
            if agentIndex == 0:  #Pacman
                bestValue = float("-inf")
                for action in state.getLegalActions(agentIndex):
                    successor = state.generateSuccessor(agentIndex, action)
                    value, _ = alphaBeta(successor, depth - 1, alpha, beta, (agentIndex + 1) % state.getNumAgents())
                    if value > bestValue:
                        bestValue = value
                        bestAction = action
                    if bestValue > beta:
                        return bestValue, bestAction
                    alpha = max(alpha, bestValue)
                return bestValue, bestAction
            else:  #Ghost
                bestValue = float("inf")
                for action in state.getLegalActions(agentIndex):
                    successor = state.generateSuccessor(agentIndex, action)
                    value, _ = alphaBeta(successor, depth - 1, alpha, beta, (agentIndex + 1) % state.getNumAgents())
                    if value < bestValue:
                        bestValue = value
                        bestAction = action
                    if bestValue < alpha:
                        return bestValue, bestAction
                    beta = min(beta, bestValue)
                return bestValue, bestAction

        _, bestAction = alphaBeta(gameState, self.depth * gameState.getNumAgents(), float("-inf"), float("inf"), 0)
        return bestAction

